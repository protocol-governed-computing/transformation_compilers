# CC_CREATE_WALLET_RECORD_V0

## Machine

```yaml
fqdn: blockchain::CC_CREATE_WALLET_RECORD_V0
artifact_kind: CAPABILITY_CONTRACT
version: v0
governed_by: capability_contracts::CONSTITUTION_CAPABILITY_CONTRACT_V0
authority: pgc.platform
concern: wallet
core:
  summary: Records the wallet with a balance of zero, its denomination and its classification
  inputs:
    wallet_id:
      type: string
      required: true
    wallet_fields:
      type: object
      required: true
  outputs:
    result_status:
      type: string
      required: true
  result_status_contract:
    allowed:
    - BACKEND_ERROR
    - VIOLATION
    - SUCCESS
    on_input_failure: VIOLATION
  pipeline:
  - step: read_created_at
    side_effect: capability_side_effects::CS_CLOCK_V0
    op: NOW
    inputs: {}
    outputs:
      timestamp: $.capability_result.timestamp
    result_surface:
    - SUCCESS
    - BACKEND_ERROR
    on_result:
      SUCCESS: continue
      BACKEND_ERROR: exit
  - step: assemble_wallet
    transform: capability_transforms::CT_PURE_ASSEMBLE_RECORD_V0
    inputs:
      fields: $.inputs.wallet_fields
    outputs:
      record: $.capability_result.record
    result_surface:
    - SUCCESS
    - VIOLATION
    on_result:
      SUCCESS: continue
      VIOLATION: exit
  - step: write_wallet
    side_effect: capability_side_effects::CS_MUTABLE_JSON_V0
    op: WRITE
    store: WALLETS
    inputs:
      key: $.inputs.wallet_id
      value: $.results.assemble_wallet.record
    outputs:
      result_status: $.capability_result.result_status
    result_surface:
    - SUCCESS
    - VIOLATION
    - BACKEND_ERROR
    on_result:
      SUCCESS: continue
      VIOLATION: exit
      BACKEND_ERROR: exit
```

---

## Intent

Records the wallet with a balance of zero, its denomination and its classification
