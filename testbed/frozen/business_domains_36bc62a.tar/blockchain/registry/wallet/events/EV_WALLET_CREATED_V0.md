# EV_WALLET_CREATED_V0

## 1. Intent

Announces that a wallet was created, for whom, and when

---

## Machine

```yaml
fqdn: blockchain::EV_WALLET_CREATED_V0
artifact_kind: EVENT
version: v0
governed_by: event::CONSTITUTION_EVENT_V0
authority: pgc.platform
concern: wallet
core:
  summary: Announces that a wallet was created, for whom, and when
  description: Announces that a wallet was created, for whom, and when
  subdomain: wallet
  schema:
    wallet_id:
      type: string
      required: true
    holder:
      type: string
      required: true
    occurred_at:
      type: string
      required: true
    timestamp:
      type: string
      format: date-time
      required: true
      description: When the moment occurred
```
