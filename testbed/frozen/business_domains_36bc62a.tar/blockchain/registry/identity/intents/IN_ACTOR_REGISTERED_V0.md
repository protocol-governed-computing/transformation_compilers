# IN_ACTOR_REGISTERED_V0

## Machine

```yaml
fqdn: blockchain::IN_ACTOR_REGISTERED_V0
artifact_kind: INTENT
version: v0
governed_by: intent::CONSTITUTION_INTENT_V0
authority: pgc.platform
concern: identity
core:
  summary: A request to admit a person as an actor
  workflow: WF_REGISTER_ACTOR_V0
  inputs:
    actor_record:
      type: object
      required: true
  outcomes:
    ACK:
      description: Request accepted for processing
    NACK:
      description: Request rejected
```

---

## Intent

A request to admit a person as an actor
