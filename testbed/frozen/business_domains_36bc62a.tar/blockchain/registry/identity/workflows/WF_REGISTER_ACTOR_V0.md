# WF_REGISTER_ACTOR_V0

## Machine

```yaml
fqdn: blockchain::WF_REGISTER_ACTOR_V0
artifact_kind: WORKFLOW
version: v0
governed_by: workflow::CONSTITUTION_WORKFLOW_V0
authority: pgc.platform
concern: identity
runtime_binding: blockchain::RB_IDENTITY_BINDINGS_V0
subdomain: identity
structure: execution::STRUCTURE_RUNTIME_EXECUTION_V0
core:
  summary: The governed sequence that admits a person as an unverified actor, records that moment as its
    own, and announces it
  actor_context: blockchain::AC_PARTICIPANT_V0
  start_node: IN_ACTOR_REGISTERED_V0
  nodes:
    IN_ACTOR_REGISTERED_V0:
      type: IN
      code: IN_ACTOR_REGISTERED_V0
      next:
        ACK: CC_VALIDATE_REGISTRATION_V0
        NACK: EXIT_REJECTED
    CC_VALIDATE_REGISTRATION_V0:
      type: CC
      code: CC_VALIDATE_REGISTRATION_V0
      inputs:
        actor_record: $.payload.actor_record
      next:
        SUCCESS: CC_CLAIM_CONTACT_ADDRESS_V0
        VIOLATION: EXIT_REJECTED
    CC_CLAIM_CONTACT_ADDRESS_V0:
      type: CC
      code: CC_CLAIM_CONTACT_ADDRESS_V0
      inputs:
        actor_record: $.payload.actor_record
        address_path: contact_address
        address_type: string
      next:
        SUCCESS: CC_REGISTER_ACTOR_V0
        ALREADY_EXISTS: CC_APPEND_ACTOR_OCCURRENCE_V0
        VIOLATION: EXIT_REJECTED
        BACKEND_ERROR: EXIT_REJECTED
    CC_REGISTER_ACTOR_V0:
      type: CC
      code: CC_REGISTER_ACTOR_V0
      inputs:
        actor_fields:
          name: $.payload.actor_record.name
          contact_address: $.payload.actor_record.contact_address
          state: UNVERIFIED
          currency_preference: $.payload.actor_record.currency_preference
          language: $.payload.actor_record.language
        contact_address: $.results.CC_CLAIM_CONTACT_ADDRESS_V0.result
      next:
        SUCCESS: CC_APPEND_ACTOR_OCCURRENCE_V0
        VIOLATION: EXIT_REJECTED
        BACKEND_ERROR: EXIT_REJECTED
    CC_APPEND_ACTOR_OCCURRENCE_V0:
      type: CC
      code: CC_APPEND_ACTOR_OCCURRENCE_V0
      inputs:
        occurrence_fields:
          occurrence: ACTOR_REGISTERED_UNVERIFIED
        stream_id: ACTOR_OCCURRENCES
        contact_address: $.results.CC_CLAIM_CONTACT_ADDRESS_V0.result
      next:
        SUCCESS: EXIT_SUCCESS
        VIOLATION: EXIT_REJECTED
        BACKEND_ERROR: EXIT_REJECTED
    EXIT_SUCCESS:
      type: EXIT
      emit: blockchain::EV_ACTOR_REGISTERED_UNVERIFIED_V0
    EXIT_REJECTED:
      type: EXIT
```

---

## Intent

The governed sequence that admits a person as an unverified actor, records that moment as its own, and announces it
