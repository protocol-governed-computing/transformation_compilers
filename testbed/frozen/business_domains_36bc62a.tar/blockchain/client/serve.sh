#!/usr/bin/env bash
#
# blockchain/identity client — composition launcher.
#
# PURPOSE: a stable, externally observable surface for exercising the COMPLETE PGC execution path
# for blockchain/identity against a KNOWN warm-boot snapshot. It is bound to that snapshot by
# design — not a production application, and it does not generalize across snapshots.
#
#   Assembled snapshot (software_governance + business_domains + workloads)
#         |
#         +-- blockchain identity client   (this surface)
#
# This script is where domain-resident knowledge lives: it points the DOMAIN-NEUTRAL transport HTTP
# adapter at this domain's roots — the web client and the HTTP binding table. Boundary declarations
# (TI/TE) are read from the sealed snapshot, never from here.
#
set -euo pipefail
CLIENT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"     # …/business_domains/blockchain/client
DOMAINS="$(cd "$CLIENT/../.." && pwd)"                     # business_domains/
UMBRELLA="$(cd "$DOMAINS/.." && pwd)"                      # protocol-governed-computing/

export PGC_RUNTIME_ROOT="$UMBRELLA/protocol_runtime"
# The transport engine knows three handler kinds; both interfaces are provisioned even for a
# composition that only executes.
export PGC_INSPECTOR_ROOT="$UMBRELLA/snapshot_inspector"
export PGC_ASSEMBLER_ROOT="$UMBRELLA/snapshot_assembler"
export PGC_IMPL_ROOTS="$UMBRELLA/software_governance:$DOMAINS"    # capability_*.* + blockchain.*
export PGC_HTTP_BINDINGS="$CLIENT/bindings/http.json"
export PGC_SNAPSHOT_ROOT="${PGC_SNAPSHOT_ROOT:-$UMBRELLA/snapshot}"
# The data root is an INSTANCE, not a user interface. The same root the CLI runs against, so a
# person registered from the web is the same person a decision recorded from the CLI is about —
# two ways in to one business, which is the whole claim the boundary makes. A root per client would
# be two disjoint worlds that happen to share a snapshot.
#
# Writes are atomic per file (temp + fsync + replace) but are not locked across read-modify-write:
# one instance driven by one person is safe, concurrent writers can lose an update.
export PGC_DATA_ROOT="${PGC_DATA_ROOT:-$UMBRELLA/data/blockchain}"
# Static mounts (all READ-ONLY, config-driven). Four roots:
#   /          the web client (splash + identity's two screens)
#   /traces    live per-run evidence from the instance data root (transient)
#   /snapshot  live inspection of the assembled snapshot (compiled artifacts)
#   /diagram   the inspector's workflow diagram, which the screens draw their workflows with
# The answer's evidence reference resolves under /traces, so the record of what happened is one
# click from the answer that reports it.
export PGC_STATIC_MOUNTS="/=$CLIENT/web;/traces=$PGC_DATA_ROOT/traces;/snapshot=$PGC_SNAPSHOT_ROOT;/diagram=$PGC_INSPECTOR_ROOT/client/web/workflow/js"
export PGC_HTTP_PORT="${PGC_HTTP_PORT:-8000}"

echo "PGC blockchain/identity client (snapshot-bound)"
echo "  client   : $CLIENT"
echo "  snapshot : $PGC_SNAPSHOT_ROOT"
echo "  data     : $PGC_DATA_ROOT"
echo "  port     : $PGC_HTTP_PORT"
echo

exec "$UMBRELLA/protocol_transport/run_http.sh"
