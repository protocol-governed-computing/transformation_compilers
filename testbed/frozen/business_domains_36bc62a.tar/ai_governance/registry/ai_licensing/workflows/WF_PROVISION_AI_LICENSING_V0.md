# WF_PROVISION_AI_LICENSING_V0

## 1. Intent

Process an AI license provisioning request with eligibility validation and cap enforcement.

---

## 2. Rationale

License provisioning is protocol-governed:
- Validates training completion
- Enforces hard license cap
- Records all decisions (success or denial)
- Denial is a first-class terminal state

---

## 3. Execution Graph

```
IN_PROVISION_AI_LICENSE_V0
    ├─ ACK → CC_VALIDATE_ELIGIBILITY_V0
    │           ├─ SUCCESS → CC_PROVISION_LICENSE_V0
    │           │               ├─ SUCCESS → CC_APPEND_AUDIT_EVENT_V0 (PROVISIONED) → EXIT:PROVISIONED
    │           │               └─ ALREADY_EXISTS/BACKEND_ERROR → EXIT:ERROR
    │           └─ VIOLATION → CC_APPEND_AUDIT_EVENT_V0 (DENIED) → EXIT:DENIED
    └─ NACK → EXIT:REJECTED
```

---

## 4. Nodes

| Node | Type | Purpose |
|------|------|---------|
| IN_PROVISION_AI_LICENSE_V0 | IN | Entry intent for provisioning |
| CC_VALIDATE_ELIGIBILITY_V0 | CC | Validate training + cap availability |
| CC_PROVISION_LICENSE_V0 | CC | Register license assignment |
| CC_APPEND_AUDIT_EVENT_V0 | CC | Record decision to audit log |
| EXIT | EXIT | Terminal node |

---

## 5. Admission

No admission requirements - test exception to allow provisioning without employee registration.

---

## Machine

```yaml
fqdn: ai_governance::WF_PROVISION_AI_LICENSING_V0
artifact_kind: WORKFLOW
version: v0
governed_by: workflow::CONSTITUTION_WORKFLOW_V0
authority: pgc.platform
concern: ai_licensing

runtime_binding: ai_governance::RB_LICENSE_BINDINGS_V0
subdomain: ai_licensing
structure: execution::STRUCTURE_RUNTIME_EXECUTION_V0

core:
  summary: Process AI license provisioning request
  actor_context: ai_governance::AC_EMPLOYEE_V0

  start_node: IN_PROVISION_AI_LICENSE_V0

  nodes:
    IN_PROVISION_AI_LICENSE_V0:
      type: IN
      code: IN_PROVISION_AI_LICENSE_V0
      next:
        ACK: CC_VALIDATE_ELIGIBILITY_V0
        NACK: EXIT_REJECTED

    CC_VALIDATE_ELIGIBILITY_V0:
      type: CC
      code: CC_VALIDATE_ELIGIBILITY_V0
      inputs:
        employee_id: $.payload.employee_id
        training_completed: $.payload.context.training_completed
        assigned_count: $.payload.context.assigned_count
        cap: $.payload.context.cap
      next:
        SUCCESS: CC_PROVISION_LICENSE_V0
        VIOLATION: CC_APPEND_AUDIT_EVENT_DENIED

    CC_PROVISION_LICENSE_V0:
      type: CC
      code: CC_PROVISION_LICENSE_V0
      inputs:
        employee_id: $.payload.employee_id
        license_id: $.payload.generated.license_id
      next:
        SUCCESS: CC_APPEND_AUDIT_EVENT_SUCCESS
        ALREADY_EXISTS: EXIT_ERROR
        VIOLATION: EXIT_ERROR
        BACKEND_ERROR: EXIT_ERROR

    CC_APPEND_AUDIT_EVENT_SUCCESS:
      type: CC
      code: CC_APPEND_AUDIT_EVENT_V0
      inputs:
        event_type: ai_governance::EV_LICENSE_PROVISIONED_V0
        employee_id: $.payload.employee_id
        decision: PROVISIONED
        reason_code: ""
        license_id: $.payload.generated.license_id
        data: {}
      next:
        SUCCESS: EXIT_PROVISIONED
        VIOLATION: EXIT_ERROR
        BACKEND_ERROR: EXIT_ERROR

    CC_APPEND_AUDIT_EVENT_DENIED:
      type: CC
      code: CC_APPEND_AUDIT_EVENT_V0
      inputs:
        event_type: ai_governance::EV_PROVISION_DENIED_V0
        employee_id: $.payload.employee_id
        decision: DENIED
        reason_code: $.payload.context.reason_code
        data: {}
      next:
        SUCCESS: EXIT_DENIED
        VIOLATION: EXIT_ERROR
        BACKEND_ERROR: EXIT_ERROR

    EXIT_PROVISIONED:
      type: EXIT
      emit: ai_governance::EV_LICENSE_PROVISIONED_V0
    EXIT_DENIED:
      type: EXIT
      emit: ai_governance::EV_PROVISION_DENIED_V0
    EXIT_REJECTED:
      type: EXIT

    EXIT_ERROR:
      type: EXIT
```
