# WF_DENY_PROVISION_V0

## 1. Intent

Handle provisioning denial by emitting denial event and recording to audit log.

---

## 2. Rationale

Denial handling ensures first-class terminal outcomes:
- Emits EV_PROVISION_DENIED_V0
- Appends to audit log
- Terminates cleanly (no retries, no loops)

---

## 3. Execution Graph

```
IN_DENY_PROVISION_V0
    ├─ ACK → CC_APPEND_AUDIT_EVENT_V0
    └─ NACK → EXIT:ERROR

CC_APPEND_AUDIT_EVENT_V0
    ├─ SUCCESS → EXIT:DENIED
    └─ VIOLATION/BACKEND_ERROR → EXIT:ERROR
```

---

## 4. Nodes

| Node | Type | Purpose |
|------|------|---------|
| IN_DENY_PROVISION_V0 | IN | Entry point for provision denial |
| CC_APPEND_AUDIT_EVENT_V0 | CC | Record denial to audit log |
| EXIT | EXIT | Terminal node |

---

## Machine

```yaml
fqdn: ai_governance::WF_DENY_PROVISION_V0
artifact_kind: WORKFLOW
version: v0
governed_by: workflow::CONSTITUTION_WORKFLOW_V0
authority: pgc.platform
concern: ai_licensing

runtime_binding: ai_governance::RB_LICENSE_BINDINGS_V0
subdomain: ai_licensing
structure: execution::STRUCTURE_RUNTIME_EXECUTION_V0

core:
  summary: Handle provisioning denial
  actor_context: ai_governance::AC_SYSTEM_V0

  start_node: IN_DENY_PROVISION_V0

  nodes:
    IN_DENY_PROVISION_V0:
      type: IN
      code: IN_DENY_PROVISION_V0
      next:
        ACK: CC_APPEND_AUDIT_EVENT_V0
        NACK: EXIT_ERROR

    CC_APPEND_AUDIT_EVENT_V0:
      type: CC
      code: CC_APPEND_AUDIT_EVENT_V0
      inputs:
        event_type: ai_governance::EV_PROVISION_DENIED_V0
        employee_id: $.payload.employee_id
        decision: DENIED
        reason_code: $.payload.reason_code
      next:
        SUCCESS: EXIT_DENIED
        VIOLATION: EXIT_ERROR
        BACKEND_ERROR: EXIT_ERROR

    EXIT_DENIED:
      type: EXIT
      emit: ai_governance::EV_PROVISION_DENIED_V0
    EXIT_ERROR:
      type: EXIT
```
