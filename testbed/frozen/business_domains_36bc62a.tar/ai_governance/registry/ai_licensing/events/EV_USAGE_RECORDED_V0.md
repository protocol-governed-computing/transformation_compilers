# EV_USAGE_RECORDED_V0

## 1. Fact

License usage activity has been recorded.

---

## 2. Rationale

Usage tracking enables autonomous reclamation:
- Injected from telemetry system
- Tracks last active date per license
- Triggers reclamation when inactivity threshold exceeded

---

## 3. Emitted By

| Source | Description |
|--------|-------------|
| Fact Injection | Telemetry system declares usage activity |

---

## 4. Schema

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| license_id | string | true | License being tracked |
| last_active_date | string (date-time) | true | When license was last used |

---

## Machine

```yaml
fqdn: ai_governance::EV_USAGE_RECORDED_V0
artifact_kind: EVENT
version: v0
governed_by: event::CONSTITUTION_EVENT_V0
authority: pgc.platform
concern: ai_licensing

core:
  summary: Usage Recorded
  subdomain: ai_licensing
  description: Emitted when license usage activity is recorded

  schema:
    license_id:
      type: string
      required: true
    last_active_date:
      type: string
      format: date-time
      required: true
    timestamp:
      type: string
      format: date-time
      required: true
      description: When the moment occurred
```
